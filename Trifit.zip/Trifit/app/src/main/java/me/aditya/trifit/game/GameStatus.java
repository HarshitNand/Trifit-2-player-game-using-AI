package me.aditya.trifit.game;

public class GameStatus {
    private GameStatus() {}

    public static final int PICK_STONE = 1;
    public static final int DRAW_STONE = 2;
    public static final int PLACE_STONE = 3;
    public static final int EAT_STONE = 4;
}
