package me.aditya.trifit.oldversion;

/**
* GameStatus together with userTurn will decide which player is in which step
 */

public class GameStatus {
    public static final String PICK_STONE = "pickStone";
    public static final String DRAW_STONE = "drawStone";
    public static final String PLACE_STONE = "placeStone";
    public static final String EAT_STONE = "eatStone";
}
