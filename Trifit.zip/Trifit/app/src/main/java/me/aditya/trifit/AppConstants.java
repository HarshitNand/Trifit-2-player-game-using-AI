package me.aditya.trifit;

public class AppConstants {

    private AppConstants() {}

    public static final String PLAYER_NAME = "playerName";
    public static final String COMPUTER_PLAYS_FIRST = "computerPlaysFirst";
    public static final String DEFAULT_PLAYER_NAME = "Noobie";
}
